import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { UsersService } from "../users.service";

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  /*Form Validation*/
  public userForm: FormGroup;
  public formFname = new FormControl('', [Validators.required]);
  public formLname = new FormControl('', [Validators.required]);
  public formCountry = new FormControl('', [Validators.required]);
  public formGender = new FormControl('', [Validators.required]);
  public formAge = new FormControl('', [Validators.required]);
  /*Form Validation*/
  public varForCollGetData: any = [];
  public varForSendPostData = {};
  public varForCollPostData = {};
  public action = "Add";
  public objectId: number = 0;
  public formSubmitted = false;

  constructor(private fB: FormBuilder, private userSer: UsersService) { }

  ngOnInit(): void {
    /*Form Validation*/
    this.userForm = this.fB.group({
      firstName: this.formFname,
      lastName: this.formLname,
      counTry: this.formCountry,
      genDer: this.formGender,
      agE: this.formAge
    });
    /*Form Validation*/
    this.loadDataOnTable();
  }

  /*Get Method*/
  loadDataOnTable() {
    this.userSer.getMethod().subscribe(data => {
      this.varForCollGetData = data;
    });
  }
  /*Get Method*/

  onSubmit() {
    this.formSubmitted = true;

    if(this.userForm.invalid) {
      // console.log("One");
      return;
    } else {
      // console.log("Two");
      // console.dir(this.userForm);
    }

    /*Post Method*/
    this.varForSendPostData = {
      fname: this.formFname.value,
      lname: this.formLname.value,
      country: this.formCountry.value,
      gender: this.formGender.value,
      age: this.formAge.value
    };
    /*Post Method*/
    
    if (this.action == "Update") {
      /*Update Method*/
      Object.assign(this.varForSendPostData,{id:this.objectId})
      this.userSer.updateMethod(this.varForSendPostData).subscribe(data => {
        // console.log(data);
        this.loadDataOnTable();
      }
      );
      /*Update Method*/
    } else {
      /*Post Method*/
      this.userSer.postMethod(this.varForSendPostData).subscribe(data => {
        this.varForCollPostData = data;
        this.loadDataOnTable(); 
      }
      );
      /*Post Method*/
    }
    
    
  }

  /*Delete Method*/
  deleteUser(currentUser) {
    this.userSer.deleteMethod(currentUser).subscribe(data => {
      this.loadDataOnTable();
    });
  }
  /*Delete Method*/

  /*Update Method*/
  editUser(selectedUser) {
    this.action = "Update";

    this.objectId = selectedUser.id;

    this.userForm.patchValue({
      firstName: selectedUser.fname,
      lastName: selectedUser.lname,
      counTry: selectedUser.country,
      genDer: selectedUser.gender,
      agE: selectedUser.age
    });

    // console.log(selectedUser);
  }
  /*Update Method*/
}