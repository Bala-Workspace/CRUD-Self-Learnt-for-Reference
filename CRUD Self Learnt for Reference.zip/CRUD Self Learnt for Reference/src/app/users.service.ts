import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";

const varForHttpOptions = {
  headers: new HttpHeaders({
    'content-type': 'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  public varForDbUrl = "http://localhost:3000/users";

  constructor(private http: HttpClient) { }

  public getMethod() {
    return this.http.get(this.varForDbUrl);
  }

  public postMethod(postObj) {
    return this.http.post(this.varForDbUrl, postObj, varForHttpOptions);
  }

  public deleteMethod(currentItem) {
    return this.http.delete(`${this.varForDbUrl}/${currentItem.id}`);
  }

  public updateMethod(selectedItem) {
    return this.http.put(`${this.varForDbUrl}/${selectedItem.id}`, selectedItem, varForHttpOptions);
  }
}